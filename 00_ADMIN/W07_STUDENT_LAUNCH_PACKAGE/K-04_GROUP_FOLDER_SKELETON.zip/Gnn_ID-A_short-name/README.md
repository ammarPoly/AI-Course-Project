# Gnn_ID-A_short-name — group folder

Rename this folder to `G<nn>_<ProjectID>-<variant>_<short-name>` (for example `G03_C1-A_freight-audit`).

| Item | Entry |
|---|---|
| Group | |
| Project and variant | |
| Members (first names or the codes the instructor uses) | |
| Where the current working version is | `02_WORK/` … |
| Latest saved version | `03_VERSIONS/` … |
| Frozen showcase version (from feature freeze) | |

Keep **one canonical folder** wherever your group already shares files. **Every member keeps a local copy of `01_PACK_AS_ISSUED/`.**
